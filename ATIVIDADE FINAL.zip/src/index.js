const express = require('express');
const { v4: uuid } = require('uuid');

const app = express();
app.use(express.json());

const usersDB = [];

// Criar Usuário

app.post('/user', (req, res) => {
	const { name, email, password } = req.body;

	if (!name || !email || !password) {
		return res.status(400).json({
			success: false,
			message: 'Digite todos os campos',
		});
	}

	const regex =
		/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

	if (!String(email).match(regex)) {
		return res.status(400).json({
			success: false,
			message: 'Digite um email válido!',
		});
	}

	const userRepeat = usersDB.some((item) => item.email === email);

	if (userRepeat) {
		return res.status(400).json({
			success: false,
			message: 'Usuário já cadastrado!',
		});
	}

	const createUser = {
		name,
		email,
		password,
		id: uuid(),
		tasks: [],
	};

	usersDB.push(createUser);
	return res.status(201).json({
		success: true,
		message: 'Usuário cadastrado com sucesso',
		data: createUser,
	});
});

// Login Usuário

app.post('/login', (req, res) => {
	const { email, password } = req.body;

	if (!email || !password) {
		return res.status(400).json({
			success: false,
			message: 'Digite todos os campos',
		});
	}
	const userLogged = usersDB.find(
		(item) => item.email === email && item.password === password
	);
	if (!userLogged) {
		return res.status(404).json({
			success: false,
			message: 'Email ou senha incorretos!',
		});
	}
	return res.status(200).json({
		success: true,
		message: 'Usuário Logado',
		data: userLogged,
	});
});

// Criar Task

app.post('/task/:uid', (req, res) => {
	const { uid } = req.params;
	const { title, description } = req.body;
	const findUser = usersDB.find((item) => item.id === uid);

	if (!findUser) {
		return res.status(404).json({
			success: false,
			message: 'Usuário não encontrado!',
		});
	}

	if (!title || !description) {
		return res.status(400).json({
			success: false,
			message: 'Digite todos os campos',
		});
	}

	const task = {
		title,
		description,
		id: uuid(),
	};

	findUser.tasks.push(task);
	return res.status(201).json({
		success: true,
		message: 'Task criada!',
		data: findUser,
	});
});

// Listar tasks do Usuário

app.get('/user/task/:uid', (req, res) => {
	const { uid } = req.params;
	const user = usersDB.find((item) => item.id === uid);

	if (!user.tasks.length) {
		return res.status(404).json({
			success: false,
			message: 'Usuário não possui tasks!',
		});
	}

	return res.status(200).json({
		success: true,
		message: 'Listando tasks',
		data: user.tasks,
	});
});

// Encontrar usuário por ID

app.get('/user/:uid', (req, res) => {
	const { uid } = req.params;

	const findUser = usersDB.find((item) => item.id === uid);

	if (!findUser) {
		return res.status(404).json({
			success: false,
			message: 'Usuário não encontrado!',
		});
	}

	return res.status(200).json({
		success: true,
		message: 'Usuário encontrado pelo ID',
		data: findUser,
	});
});

// Atualizar task de determinado usuário

app.put('/task/update/:uid/:taskuid', (req, res) => {
	const { uid, taskuid } = req.params;
	const { newTitle, newDescription } = req.body;

	if (!newTitle && !newDescription) {
		return res.status(400).json({
			success: false,
			message: 'Digite todos os campos',
		});
	}

	const findUser = usersDB.find((item) => item.id === uid);

	if (!findUser) {
		return res.status(404).json({
			success: false,
			message: 'Usuário não encontrado!',
		});
	}

	const findTask = findUser.tasks.find((task) => task.id === taskuid);

	if (!findTask) {
		return res.status(404).json({
			success: false,
			message: 'Usuário não encontrado!',
		});
	}

	findTask.title = newTitle ? newTitle : findTask.title;
	findTask.description = newDescription ? newDescription : findTask.description;

	return res.status(200).json({
		success: true,
		message: 'Task Atualizada',
		data: findUser.tasks,
	});
});

// Delete task de determinado usuario

app.delete('/user/:uid/:taskuid', (req, res) => {
	const { uid, taskuid } = req.params;

	const findUser = usersDB.find((item) => item.id === uid);

	if (!findUser) {
		return res.status(404).json({
			success: false,
			message: 'Usuário não encontrado!',
		});
	}

	const findTaskIndex = findUser.tasks.findIndex((task) => task.id === taskuid);

	if (findTaskIndex < 0) {
		return res.status(404).json({
			success: false,
			message: 'Task não encontrada!',
		});
	}

	findUser.tasks.splice(findTaskIndex, 1);

	return res.status(200).json({
		success: true,
		message: 'Task deletada',
		data: findUser,
	});
});

app.listen(3333, () => console.log('Servidor rodando na porta 3333'));
